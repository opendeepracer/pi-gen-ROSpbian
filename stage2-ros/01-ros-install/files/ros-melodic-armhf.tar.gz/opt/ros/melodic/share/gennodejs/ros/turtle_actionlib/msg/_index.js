
"use strict";

let Velocity = require('./Velocity.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeFeedback = require('./ShapeFeedback.js');

module.exports = {
  Velocity: Velocity,
  ShapeAction: ShapeAction,
  ShapeActionGoal: ShapeActionGoal,
  ShapeGoal: ShapeGoal,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeActionResult: ShapeActionResult,
  ShapeResult: ShapeResult,
  ShapeFeedback: ShapeFeedback,
};

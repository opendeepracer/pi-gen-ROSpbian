This package uses the Liberation Sans font.

https://en.wikipedia.org/wiki/Liberation_fonts

https://www.fontsquirrel.com/fonts/Liberation-Sans

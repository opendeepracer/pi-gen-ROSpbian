
"use strict";

let Color = require('./Color.js');
let Pose = require('./Pose.js');

module.exports = {
  Color: Color,
  Pose: Pose,
};

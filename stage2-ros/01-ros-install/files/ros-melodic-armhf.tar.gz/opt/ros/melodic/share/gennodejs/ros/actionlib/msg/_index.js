
"use strict";

let TestRequestGoal = require('./TestRequestGoal.js');
let TestActionGoal = require('./TestActionGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestFeedback = require('./TestFeedback.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestActionResult = require('./TestActionResult.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestResult = require('./TestResult.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestGoal = require('./TestGoal.js');
let TestRequestAction = require('./TestRequestAction.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestAction = require('./TestAction.js');

module.exports = {
  TestRequestGoal: TestRequestGoal,
  TestActionGoal: TestActionGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TwoIntsAction: TwoIntsAction,
  TestRequestActionGoal: TestRequestActionGoal,
  TestFeedback: TestFeedback,
  TestRequestFeedback: TestRequestFeedback,
  TestActionResult: TestActionResult,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestRequestResult: TestRequestResult,
  TwoIntsGoal: TwoIntsGoal,
  TestActionFeedback: TestActionFeedback,
  TestResult: TestResult,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestActionResult: TestRequestActionResult,
  TwoIntsResult: TwoIntsResult,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestGoal: TestGoal,
  TestRequestAction: TestRequestAction,
  TwoIntsActionResult: TwoIntsActionResult,
  TestAction: TestAction,
};
